﻿using UnityEngine;
using System.Collections;

public static class PermanentVar {

	public static bool CanTransformRond = true;
	//public static bool CanTransformTriangle = false;
	public static bool CanHeavy = false;
	public static bool CanInvisible = false;

	public static int WeightSoft = 20;
	public static int WeightHeavy = 100;
}
